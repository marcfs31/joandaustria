#!/usr/bin/env python
# -*- coding: utf-8 -*-

num=int(input("Introdueix un nimero: "))

num = num+1

print("La suma té",len(str(num)),"xifres") #Convierte num en string y imprime su longitud

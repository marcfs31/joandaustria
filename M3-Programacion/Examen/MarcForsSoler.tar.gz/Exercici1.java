import java.io.*;
public class Exercici1 {
	public static void main (String[] args) throws IOException  {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		
		//Iniciar y declarar variables
		int hores,minuts,segons,major;
		String hores_str,minuts_str,segons_str,gran;
		
		//Coger cantidad de numeros
		System.out.print("Introdueix les hores: ");
		hores_str= reader.readLine();
		hores = Integer.parseInt(hores_str);
		
		System.out.print("Introdueix els minuts: ");
		minuts_str= reader.readLine();
		minuts = Integer.parseInt(minuts_str);
		
		System.out.print("Introdueix els segons: ");
		segons_str= reader.readLine();
		segons = Integer.parseInt(segons_str);
		
		//Evaluar cual es el mayor
		if(hores > minuts){
			major = hores;
			gran="hores";
		}else if(minuts > segons){
			major = minuts;
			gran="minuts";
		}else{
			major = segons;
			gran="segons";
		}
		
		for(int a=major;a>=0;a--){
			if(hores <= 0 && minuts <= 0){
				System.out.println("00"+":"+"00"+":"+a);
			}else if(hores <= 0 && minuts >= 0){
				if(minuts<10){
					System.out.println("00"+":"+"0"+(minuts--)+":"+a);
				}else{
					System.out.println("00"+":"+(minuts--)+":"+a);
				}
			}else{
				if(hores<10){
					System.out.println("0"+(hores--)+":"+"00"+":"+a);
				}else{
					System.out.println((hores--)+":"+"00"+":"+a);
				}
			}
		}
		
		/*
		for(int i=hores;i>=0;i--){
			if(i<10){
				System.out.println("0"+i+":");
			}else{
				System.out.println(i+":");
			}
		}
		
		for(int x=minuts;x>=0;x--){
			if(x<10){
				System.out.print(":0"+x+":");
			}else{
				System.out.print(":"+x+":");
			}
		}
		
		for(int z=segons;z>=0;z--){
			if(z<10){
				System.out.println("0"+z);
			}else{
				System.out.println(z);
			}
		}
		*/
	}
}


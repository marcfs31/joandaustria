#!/usr/bin/env python
# -*- coding: utf-8 -*-

nombre = input("Como te llamas? ")

print(nombre.upper()) # .upper() pasa el string a mayusculas

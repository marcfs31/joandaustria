#!/usr/bin/env python
# -*- coding: utf-8 -*-
for x in range(0,101):
	print(x)

#range(0,10,1) # te saca los numeros del 1 al 10 de 1 en 1 tal cual no lo guarda en ningun sitio
#range(10)
#range(0,10,2)	

#!/usr/bin/env python
# -*- coding: utf-8 -*-
num = int(input("Introdueix un enter: "))

if(num < 4):
	print("ERROR entrada ha d'esser major o igual a 4'")

for x in range(1):
	print("*  *")
	print("** *")
	print("* **")
	print("*  *")
